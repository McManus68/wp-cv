<?php

    /*
    Plugin Name: Klb Shortcode
    Plugin URI: http://themeforest.net/user/klbtheme/portfolio
    Description: Plugin for displaying theme shortcodes.
    Author: KlbTheme
    Version: 1.5
    Author URI: http://themeforest.net/user/klbtheme/portfolio
    */

/*-----------------------------------------------------------------------------------*/
/*	Unica Button
/*-----------------------------------------------------------------------------------*/

function unica_button( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "link"    	     => '',
        "useicon"    	     => '',
        "icons"    	     => '',
        "btn_type"    	     => '',
        "btn_class"    	     => '',
        "icon_fontawesome"    	     => '',
        "hovercolor"    	     => '',
        "buttoncolor"    	     => '',
        "bordercolor"    	     => '',
        "backgroundcolor"    	     => '',
        "btnalignment"    	     => '',



    ), $atts) );
	
        $output = '';
		
		?>
		 <?php $hovercolor1 = str_replace(array('#','.',',','(',')'),'',$hovercolor); ?>
        <?php if($hovercolor) { ?>
		<style>
            

			.klb-button .klb_<?php echo esc_html($hovercolor1) ?>:hover {
				    background-color: <?php echo esc_html($hovercolor); ?>;			
			}
			.klb-button .klb_<?php echo esc_html($hovercolor1) ?>{
				background-color: <?php echo esc_html($backgroundcolor); ?>;
			}
		</style>
		<?php } ?>
		<?php
		$alignment = '';
		
		if($btnalignment == 'center'){
		  $alignment .= 'center';
		} elseif($btnalignment == 'right'){
		  $alignment .= 'right';	
		} else {
		  $alignment .= 'left';	
		}
				$link = ( '||' === $link ) ? '' : $link;
				$link = vc_build_link( $link );
				$a_href = $link['url'];
				$a_title = $link['title'];
				$a_target = $link['target'];
				
		$output .= '<div class="klb-button" style="text-align:'.esc_html($alignment).';">';
		if($icons){
			$useicon .= '<i class="'.$icon_fontawesome.'"></i>';
		}
		if($btn_type == '1'){
			$btn_class = 'btn';
		}elseif($btn_type == '2'){
			$btn_class = 'btn-s';
		}elseif($btn_type == '3'){
			$btn_class = 'btn-l';
		}elseif($btn_type == '4'){
			$btn_class = 'btn-bordered';
		}elseif($btn_type == '5'){
			$btn_class = 'btn-bordered btn-s';
		}elseif($btn_type == '6'){
			$btn_class = 'btn-bordered btn-l';
		}
		$output .= '<a class="btn '.esc_attr( $btn_class ).' klb_'.$hovercolor1.'" style="border-color:'.esc_attr($bordercolor).';color:'.esc_attr($buttoncolor).'" href="'.esc_attr( $a_href ).'" target="'.esc_attr( $a_target ).'" title="'.esc_attr( $a_title ).'">'.$useicon.''.esc_html( $a_title ).'</a>';
		$output .= '</div>';

								
  		return $output;
}

add_shortcode('button_unica', 'unica_button');


/*-----------------------------------------------------------------------------------*/
/*	Unica Section Title
/*-----------------------------------------------------------------------------------*/

function unica_title( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"    	     => '',
        "sepon"    	     => '',
        "bgcolor"   => '',
        "sepcolor"   => '',

    ), $atts) );
	
            $output = '';
            
			$output .= '<header class="heading" ';
			if($bgcolor){
			
			$output .= 'style="color:'.$bgcolor.';"';
			
			} 

			$output .= '>';
			$output .= '<h2>'.$title.'</h2>';

		    if($sepon == true ) {
		      $output .= '<div style="color:'.esc_attr( $sepcolor ).';" class="separator"></div>';
			}	
			$output .= '</header>	';	
								
  		return $output;
}

add_shortcode('title_unica', 'unica_title');

/*-----------------------------------------------------------------------------------*/
/*	Unica Intro Header Section
/*-----------------------------------------------------------------------------------*/

function unica_intro( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"    	    	 => '',
        "bgcolor"    	     => '',
        "subtitle"    	     => '',
		"icon_fontawesome"   => '',
		"image_url"       	 => '',
		"firstsubtitle"      => '',
		"link"       		 => '',
		"titlecolor"       	 => '',
		"subtitlecolor"      => '',
		"fsubtitlecolor"     => '',
		"butoncolor"       	 => '',
		"buttonbordercolor"  => '',
		"aftersubcolor"  => '',
		"buttonradius" 		 => '',
		"sepcolor"  		 => '',
		"social"  		 => '',
		"socialurl"  		 => '',
		"icon_fontawesome"  		 => '',
		"socialcolor"  		 => '',
		"logo"  		 => '',
		"icon"  		 => '',
		"sepon"  		 => '',
		"contentalignment"  		 => '',
		"image_urlt"  		 => '',
		"aftersubtitle"  		 => '',
		"particles"  		 => '',
		"values"      	 	 => '',
		"value"      	 	 => '',
    ), $atts) );
	
            $output = '';
				$alignment = '';
				if($contentalignment == 'center'){
				  $alignment .= 'center';
				} elseif($contentalignment == 'right'){
				  $alignment .= 'right';	
				} else {
				  $alignment .= 'left';	
				}		
			$output .= '<div class="intro">';
			$output .= '<header class="heading" style="text-align:'.$alignment.'">';
			$image_urlss = wp_get_attachment_url( $image_urlt, 'full' );
			if( $logo == true){
			$output .= '<img class="klb-intro-logo wow fadeInUp" src="'.$image_urlss.'" width="100" height="96" alt="">';
			}
			if ( $icon == true){
			$output .= '<i data-wow-delay="0.1s" class="fa-4x '.$icon_fontawesome.' wow fadeInDown" style ="color:'.esc_attr( $bgcolor ).';"></i>';
			}
			
			$output .= '<h1 class="wow zoomIn"><span style="color:'.esc_attr( $titlecolor ).';" class="name">'.$title.'</span><span class="animated-letters category">';
			
			$output .= '<b class="is-visible" style="color:'.esc_attr( $fsubtitlecolor ).';" >'.$firstsubtitle.'</b>';
			
			$values = (array) vc_param_group_parse_atts($values);

	         foreach($values as $v) {
				 
				$output .= '<b style="color:'.esc_attr( $v['subtitlecolor'] ).';">'.$v['subtitle'].'</b>';
				
			} 
			
				$link = ( '||' === $link ) ? '' : $link;
				$link = vc_build_link( $link );
				$a_href = $link['url'];
				$a_title = $link['title'];
				$a_target = $link['target'];
				
			$output .= '</span>';
			$output .= '</h1>';
			$output .= '<p data-wow-delay="0.2s" class="wow fadeInUp" style="color:'.$aftersubcolor.'">'.$aftersubtitle.'</p>';
			if($sepon == true){
			$output .= '<div style="color:'.esc_attr( $sepcolor).';" class="separator wow zoomIn"></div>';
			}
			$output .= '</header>';
			if(empty($a_title)){
			}else{
			$output .= '<div style="color:'.$buttonbordercolor.';"data-wow-delay="0.1s" class="wow fadeInUp"><a  href="'.esc_attr( $a_href ).'" target="'.esc_attr( $a_target ).'" title="'.esc_attr( $a_title ).'" style="border-radius:'.$buttonradius.'px;" class="btn btn-bordered btn-go"><span style="color:'.$butoncolor.'">'.esc_attr( $a_title ).'</span></a></div>';
			}
			
			if($social == true){
			$output .= '<div data-wow-delay="0.1s" class="wow fadeInUp">';
			$output .= '<ul class="social-nav">';
			 $value = (array) vc_param_group_parse_atts($value);
	         foreach($value as $v) {
				$output .= '<li><a href="'.$v['socialurl'].'"><i class="'.$v['icon_fontawesome'].'" style="color:'.$v['socialcolor'].'"></i></a></li>';
			 }
			$output .= '</ul>';
			$output .= '</div>';
			}
			
			$output .= '</div>';
			if($particles){
			$output .= '<canvas id="particles"></canvas>';
			}
										
  		return $output;
}

add_shortcode('header_unica', 'unica_intro');

/*-----------------------------------------------------------------------------------*/
/*	Unica About Section
/*-----------------------------------------------------------------------------------*/

function unica_about( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"    	         => '',
		"icon_fontawesome"   => '',
		"icon_link" 		 => '',
		"image_url"       	 => '',
		"image_urlt"       	 => '',
		"fontawesome"       	 => '',
		"iconlink"       	 => '',
		"values"      	 	 => '',
    ), $atts) );
	
            $output = '';
			$output .= '<div class="row">';

			$image_urls = wp_get_attachment_url( $image_url, 'full' );
			
			$output .= '<div class="col span_4 center">';
			if (empty($image_url)){
			$output .= '</div>';
			$output .= '<div class="col span_12">';
			$output .= '<h3>'.$title.'</h3>';
			$output .= '<p>'.do_shortcode($content).'</p>';
			$output .= '<ul class="social-nav">';
			}else{
				$output .= '<div class="site-photo"><img src = "'.$image_urls.'" width="250" height="250" alt="Photo" class="photo"></div>';
			$output .= '</div>';
			$output .= '<div class="col span_8">';
			$output .= '<h3>'.$title.'</h3>';
			$output .= '<p>'.do_shortcode($content).'</p>';
			if($image_urlt){
			$image_urlst = wp_get_attachment_url( $image_urlt, 'full' );
			$output .= '<img src="'.$image_urlst.'" width="153" height="61" alt="">';
			}
			$output .= '<ul class="social-nav">';
			}
			
			$values = (array) vc_param_group_parse_atts($values);

	         foreach($values as $v) {
				$output .= '<li><a href="'.esc_attr($v['icon_link']).'"><i class="'.esc_attr($v['icon_fontawesome']).'"></i></a></li>';		
			} 
			$output .= '</ul>';
			$output .= '</div>';
			$output .= '</div>';
									
  		return $output;
}

add_shortcode('about_unica', 'unica_about');

/*-----------------------------------------------------------------------------------*/
/*	Unica Experince Section
/*-----------------------------------------------------------------------------------*/

function unica_exper( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "years"    	         => '',
		"icon_fontawesome"   => '',
		"bgcolor"   => '',
		"title" 		 => '',
		"values"      	 	 => '',
    ), $atts) );
	
            $output = '';
			$output .= '<div class="expirience">';
			$values = (array) vc_param_group_parse_atts($values);

	         foreach($values as $v) {
				 $colorbg ='';
				if(isset($v['bgcolor'])){
					$colorbg .= $v['bgcolor'];
				}
				$output .= '<div class="expirience-item">';
				$output .= '<div class="icon-b wow bounceIn"><i class="'.$v['icon_fontawesome'].'" style="color:'.esc_attr( $colorbg ).'"></i></div>';
				$output .= '<div class="expirience-item-inner wow bounceInRight">';		
				$output .= '<div class="date">'.$v['years'].'</div>';
				$output .= '<h3>'.$v['title'].'</h3>';
				$output .= '<p>'.do_shortcode($v['content']).'</p>';
				$output .= '</div>';
				$output .= '</div>';
				
			} 
			$output .= '</div>';				
  		return $output;
}

add_shortcode('exper_unica', 'unica_exper');

/*-----------------------------------------------------------------------------------*/
/*	Unica Services Section
/*-----------------------------------------------------------------------------------*/

function unica_services( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "boxcolor"    	         => '',
		"icon_fontawesome"   => '',
		"bgcolor"   => '',
		"titlecolor"   => '',
		"contentcolor"   => '',
		"iconbg"   => '',
		"title" 		 => '',
		"justbig" 		 => '',
    ), $atts) );
	
		$output = '';
		?>

       <?php $iconbg1 = str_replace(array('#','.',',','(',')'),'',$iconbg); ?>
        <?php if($iconbg) { ?>
		<style>

			.services .klb_<?php echo esc_html($iconbg1) ?>:before {
				    background-color: <?php echo esc_html($iconbg); ?>;			
			}

		</style>
		<?php } ?>
		<?php
		
		$output .= '<div class="services">';
		if($justbig == true){
		$output .= '<div style="color:'.esc_attr( $boxcolor ).'" ><i style="color:'.esc_attr( $bgcolor ).';" class="fa-3x '.$icon_fontawesome.'"></i></div>';
		}else{
		$output .= '<div style="color:'.esc_attr( $boxcolor ).'" class="icon-b klb_'.$iconbg1.'"><i style="color:'.esc_attr( $bgcolor ).';" class="'.$icon_fontawesome.'"></i></div>';
		}
		$output .= '<h3 style ="color:'.esc_attr( $titlecolor ).'">'.$title.'</h3>';
		$output .= '<p style ="color:'.esc_attr( $contentcolor ).'">'.do_shortcode($content).'</p>';
		$output .= '</div>';
  		return $output;
}

add_shortcode('services_unica', 'unica_services');

/*-----------------------------------------------------------------------------------*/
/*	Unica Skill Section
/*-----------------------------------------------------------------------------------*/

function unica_skill( $atts, $content = null ) {
    extract( shortcode_atts(array(       
		"numbers" 		     => '',
		"yourskill" 		 => '',
		"skillcolor" 		 => '',
		"barcolor" 		     => '',
		"values"      	 	 => '',
    ), $atts) );
	
            $output = '';

			$output .= '<div class="skills">';
			$values = (array) vc_param_group_parse_atts($values);

	         foreach($values as $v) {
				 
				$colorbar = '';
				$colorskill ='';
				
				if(isset($v['barcolor'])){
					$colorbar .= $v['barcolor'];
				}
				if(isset($v['skillcolor'])){
					$colorskill .= $v['skillcolor'];
				}
				 	 
				$output .= '<div  data-progress="'.$v['numbers'].'" class="skills-item wow">';
				$output .= '<div style="color:'.esc_attr( $colorbar ).'" class="skills-item-progress"></div>';
				$output .= '<h4 style="color:'.esc_attr( $colorskill ).'">'.$v['yourskill'].'</h4>';
				$output .= '</div>';
			} 
			$output .= '</div>';
		
  		return $output;
}

add_shortcode('skill_unica', 'unica_skill');

/*-----------------------------------------------------------------------------------*/
/*	Unica Textbox 
/*-----------------------------------------------------------------------------------*/

function unica_textbox( $atts, $content = null ) {
    extract( shortcode_atts(array(       

		"sepon"              => '',
		"bgcolor"            => '',
		"title" 		     => '',
		"contentcolor" 		 => '',
		"titlecolor" 		 => '',
		"values"      	 	 => '',
    ), $atts) );
	
		$output = '';
		
		$output .= '<h3 style="color:'.$titlecolor.'">'.$title.'</h3>';	
		 if($sepon == true ) {	 
		  $output .= '<div class="separator l" style="color:'.$bgcolor.';"></div>';
		}
		$output .= '<div style="color:'.$contentcolor.'">';
		$output .= '<p>'.do_shortcode($content).'</p>';
		$output .= '</div>';
		return $output;
}

add_shortcode('textbox_unica', 'unica_textbox');


/*-----------------------------------------------------------------------------------*/
/*  Unica Portfolio
/*-----------------------------------------------------------------------------------*/

function unica_portfolio( $atts, $content = null ) {	
    extract( shortcode_atts(array(    
	
        "image_url"   => '',
        "title"       => '',
        "subtitle"    => '',	
        "filtercolor"    => '',	
        "gallery"    => '',	
       	"categories"    => 'all', 	
        "posts"    => '3',	
		"width"    => '750',	
        "height"    => '500',
	
    ), $atts) );
	
    $output = '';	
    $output2 = '';	
	
	$post_format = '';	  
	$post_format1 = '';	 
    global $post;
    $portfolio_filters = get_terms('portfolio_category'); 
	if($portfolio_filters):	
	$output2 .= '<ul class="filter" style="color:'.esc_attr($filtercolor).';">';
	$output2 .= '<li data-group="all" class="active">'.esc_html__('All','unica').'</li>';
	foreach($portfolio_filters as $portfolio_filter):
		if($categories == 'all'){
		 $output2 .= '<li data-group="'.esc_attr($portfolio_filter->slug).' ">'.esc_attr($portfolio_filter->name).'</li>';
		} else {
			$str = str_replace(',',' ',$categories);
			$category = explode(' ',$str);
			
			if ( in_array( $portfolio_filter->slug, $category ) ) { 
		      $output2 .= '<li data-group="'.esc_attr($portfolio_filter->slug).'">'.esc_attr($portfolio_filter->name).'</li>';
			}
		}
	endforeach;
	$output2 .= '</ul>';
    endif;
	
    $paged = get_query_var('paged') ? get_query_var('paged') : 1;
	$args = array(
		'post_type' => 'portfolio',  
		'posts_per_page' => $posts,
		'order'          => 'DESC',
		'orderby'        => 'date',  
		'post_status'    => 'publish',
		'post_taxonomy'    => $categories,
        'paged' 			=> $paged
    );
	
    if($categories != 'all'){
    	// string to array
    	$str = $categories;
    	$arr = explode(',', $str);
    	//var_dump($arr);
    	
		$args['tax_query'][] = array(
			'taxonomy' 	=> 'portfolio_category',
			'field' 	=> 'slug',
			'terms' 	=> $arr
		);
	}
    query_posts( $args );
 
	
	if( have_posts() ) : while ( have_posts() ) : the_post();
		//control for icon	
		if(has_post_thumbnail() ){
			if(has_post_format( 'audio' )){
			  $icon = '<i class="proicon fa fa-music"></i>';	
			}elseif ( has_post_format( 'gallery' )) {
			  $icon = '<i class="proicon fa fa-camera"></i>';	
			}elseif ( has_post_format( 'video' )){
			 $icon = '<i class="proicon fa fa-film"></i>';	
			}else{
			 $icon = '<i class="proicon fa fa-image"></i>';
			}		
		}	
		
	$blog_image= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "full" );				
	$imagem = unica_resize( $blog_image[0], $width, $height, true, true, true );  
	
	$terms = get_the_terms( get_the_ID(), 'portfolio_category' );
	$taxonomy = strip_tags( get_the_term_list($post->ID, 'portfolio_category', '', ' - ', '') );
	
	if($gallery == true ){
		$output .= '<div class="gallery-item"><a href="'.$imagem.'" title="'.get_the_title().'"><img src="'.$imagem.'" width="250" height="250" alt=""></a></div>';	
	}else{
	$output .= '<li data-groups="[&quot;';
					  if($terms) : foreach ($terms as $term) {
					  $output .= ''.$term->slug.' ';
				  } endif;
	$output .= '&quot;]" class="works-item">';
	$output .= '<a href="#'.get_the_ID().'" class="works-item-link"><span class="works-item-thumb">';
	$output .= '<img src="'.$imagem.'" width="500" height="500" alt="">';
	$output .= '</span>';
	$output .= $icon;	
	$output .= '</a>';
	$output .= '<div id="'.get_the_ID().'" class="popup mfp-hide">';
	$output .= '<figure>';
	if(has_post_thumbnail() ){
		
		if(has_post_format( 'audio' )){ 			
			$output .= '<figure class="entry-thumb">'.get_post_meta($post->ID, 'klb_portfolioaudiourl', true).'</figure>';
		}elseif ( has_post_format( 'gallery' )) {
			 $slideimage = rwmb_meta( 'klb_portfolioitemslides', 'type=image_advanced' );
			 $output .= '<div class="slideshow owl-carousel owl-theme">';
			 foreach ( $slideimage as $image ) {
			  $slideaq = unica_resize( $image['full_url'], 750, 500, true, true, true );   
			  $output .= '<div class="item"><img src="'.$slideaq.'" alt="" /></div>';
			 }
			 $output .= '</div>';			
		}elseif ( has_post_format( 'video' )) {			
		   $output .= '<div class="entry-media">';
		   if (get_post_meta( get_the_ID(), 'klb_portfolio_video_type', true ) == 'vimeo') { 
			  $output .='<iframe src="http://player.vimeo.com/video/'.get_post_meta( get_the_ID(), 'klb_portfolio_video_embed', true ).'?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" width="750" height="540" allowFullScreen></iframe>'; 
		   }
		   elseif (get_post_meta( get_the_ID(), 'klb_portfolio_video_type', true ) == 'youtube') { 
			$output .='<iframe width="750" height="303" src="http://www.youtube.com/embed/'.get_post_meta( get_the_ID(), 'klb_portfolio_video_embed', true ).'?rel=0&showinfo=0&modestbranding=1&hd=1&autohide=1&color=white" allowfullscreen></iframe>';  
		   }
		   else {  
			$output .=' '.get_post_meta( get_the_ID(), 'klb_blog_video_embed', true ).' '; 
		   } 
		   $output .= '</div>';		   
		}else{
			$output .= '<img src="'.$imagem.'" width="750" height="500" alt="">';

		}
	}
	$output .= '</figure>';
	$output .= '<div class="popup-inner">';
	$output .= '<h3>'.get_the_title().'</h3>';
	$output .= '<p>'.get_the_content().'</p>';
	$output .= '</div>';
	$output .= '</div>';
	$output .= '</li>';	
	}
	endwhile;
	wp_reset_query();
	endif;	
	
    if($gallery == true ){
    return '<div class="gallery">'.$output.'</div>';  
	}else{
    return $output2.'<ul class="works">'.$output.'</ul>';  
	}

}

add_shortcode('portfolio', 'unica_portfolio');


/*-----------------------------------------------------------------------------------*/
/*	Unica Testimonials Section
/*-----------------------------------------------------------------------------------*/

function unica_testimonials( $atts, $content = null ) {
    extract( shortcode_atts(array(       
		"image_url" 		 => '',
		"clientcolor" 		 => '',
		"contentcolor" 		 => '',
		"content" 		     => '',
		"dotcolors" 		     => '',
		"client" 		     => '',
		"values"      	 	 => '',
		"time"      	 	 => '5000',
    ), $atts) );
	
            $output = '';

			wp_enqueue_script('unica_testimonial'); 
			wp_localize_script('unica_testimonial', 'testimonial' , 
			   array( 
				 'autoplay' => $time,
				));	

			$output .= '<div class="slideshow testimonials">';
			$values = (array) vc_param_group_parse_atts($values);

	         foreach($values as $v) {
				 
				$colorclient = '';
				$colorcontent ='';
				$image_urls = wp_get_attachment_url( $v['image_url'], 'full' );
				if(isset($v['clientcolor'])){
					$colorclient .= $v['clientcolor'];
				}
				if(isset($v['contentcolor'])){
					$colorcontent .= $v['contentcolor'];
				}

				
				$output .= '<blockquote style="color:'.esc_attr( $colorcontent ).'">';
				$output .= '<p>'.$v['content'].'</p>';
				$output .= '<div style="color:'.esc_attr( $colorclient ).'" class="author">'.$v['client'].'</div>';
				$output .= '<div class="site-photo"><img src="'.$image_urls.'" width="70" height="70" alt=""></div>';
				$output .= '</blockquote> '; 
				
				
		  
			} 
			?>
            <?php if($dotcolors) { ?>
			<style>
				.owl-unica .owl-pagination .owl-page{
					color:<?php echo esc_attr($dotcolors) ?>
				}
			</style>
            <?php } ?>

			<?php
			$output .= '</div>';
	
  		return $output;
}

add_shortcode('testimonials_unica', 'unica_testimonials');

/*-----------------------------------------------------------------------------------*/
/*	Unica Clients Section
/*-----------------------------------------------------------------------------------*/

function unica_clients( $atts, $content = null ) {
    extract( shortcode_atts(array(       
		"image_url" 		 => '',
		"setwidth" 		 => '',
		"setheight" 		 => '',
		"values"      	 	 => '',
		"time"      	 	 => '5000',
    ), $atts) );
	
            $output = '';

			wp_enqueue_script('unica_clients'); 
			wp_localize_script('unica_clients', 'clients' , 
			   array( 
				 'autoplay' => $time,
				));	

			$output .= ' <div class="clients">';
			$values = (array) vc_param_group_parse_atts($values);

	         foreach($values as $v) {
				$height = '';
				$width ='';		
				if(isset($v['setwidth'])){
					$width .= $v['setwidth'];
				}
				if(isset($v['setheight'])){
					$height .= $v['setheight'];
				}
				 
			$image_urls = wp_get_attachment_url( $v['image_url'], 'full' );

			$output .= '<div class="clients-item"><img src="'.$image_urls.'" alt="client"></div>';
				
			} 
			$output .= '</div>';
	
  		return $output;
}

add_shortcode('clients_unica', 'unica_clients');

/*-----------------------------------------------------------------------------------*/
/*	Unica Contact Address Section
/*-----------------------------------------------------------------------------------*/

function unica_contact( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "iconcolor"    	         => '',
		"icon_fontawesome"   => '',
		"contentcolor"   => '',
		"bordercolor"   => '',
		"bgcolor"   => '',

    ), $atts) );
		?>


			<?php $bgcolor1 = str_replace(array('#','.',',','(',')'),'',$bgcolor); ?>
            <?php if($bgcolor) { ?>
			<style>

				.klb_<?php echo esc_html($bgcolor1) ?>:before {
						background-color: <?php echo esc_html($bgcolor); ?>;			
				}
			</style>
            <?php } ?>

		<?php
		$output = '';
		$output .= '<div class="contacts">';
		$output .= '<div class="contacts-item">';
		$output .= '<div style="color:'.esc_attr( $bordercolor).';" class="icon-b klb_'.$bgcolor1.'"><i style="color:'.esc_attr( $iconcolor).';" class="'.$icon_fontawesome.'"></i></div>';
		$output .= '<address style="color:'.esc_attr( $contentcolor).';" class="adr"><span class="country-name">'.do_shortcode($content).'</span></address>';
		$output .= '</div>';
		$output .= '</div>';

  		return $output;
}

add_shortcode('contact_unica', 'unica_contact');

/*-----------------------------------------------------------------------------------*/
/*	Unica Our Team Section
/*-----------------------------------------------------------------------------------*/

function unica_ourteam( $atts, $content = null ) {
    extract( shortcode_atts(array(       
        "title"    	         => '',
		"icon_fontawesome"   => '',
		"subtitle"   		 => '',
		"socialurl"  		 => '',
		"socialcolor"  		 => '',
		"image_url"  		 => '',
		"values"  			 => '',

    ), $atts) );
	
		$output = '';
		$output .= '<div class="profile">';
		$image_urls = wp_get_attachment_url( $image_url, 'full' );
		$output .= '<div class="profile-photo"><img src="'.$image_urls.'" alt=""></div>';
		$output .= '<h3>'.$title.'</h3>';
		$output .= '<h4>'.$subtitle.'</h4>';
		$output .= '<p>'.do_shortcode($content).'</p>';
		
		$output .= '<ul class="social-nav">';
		
			$values = (array) vc_param_group_parse_atts($values);
	         foreach($values as $v) {
			 $output .= '<li><a href="'.$v['socialurl'].'"><i class="'.$v['icon_fontawesome'].'"></i></a></li>';
			 }
		$output .= '</ul>';
		
		$output .= '</div>';


  		return $output;
}

add_shortcode('ourteam_unica', 'unica_ourteam');

/*-----------------------------------------------------------------------------------*/
/*	Unica Pricing Section
/*-----------------------------------------------------------------------------------*/

function unica_pricing( $atts, $content = null ) {
    extract( shortcode_atts(array(       
		"listitem" 		     => '',
		"title" 		 => '',
		"currency" 		 => '',
		"amount" 		     => '',
		"period"      	 	 => 'monthly',
		"link"    	     => '',
        "useicon"    	     => '',
        "icons"    	     => '',
        "btn_type"    	     => '',
        "btn_class"    	     => '',
        "icon_fontawesome"    	     => '',
        "hovercolor"    	     => '',
        "buttoncolor"    	     => '',
        "bordercolor"    	     => '',
        "backgroundcolor"    	     => '',
        "btnalignment"    	     => '',
        "bestvalue"    	     => '',
        "bestvalue1"    	     => '',
        "contentcolor"    	     => '',
        "titlecolor"    	     => '',
        "bgcolor"    	     => '',
        "values"    	     => '',
    ), $atts) );
	
            $output = '';
			$bestvalue1 = '';
			if($bestvalue == true){
				$bestvalue1 = 'content-box-dark';
			}else{
				$bestvalue1 = 'content-box-light';
			}
			$output .= '<div class="pricing '.$bestvalue1.'" style="color:'.esc_attr($contentcolor).';background-color:'.esc_attr($bgcolor).'">';
			$output .= '<h3 style="color:'.esc_attr($titlecolor).'">'.$title.'</h3>';
			$output .= '<div class="pricing-item-value"><sup>'.$currency.'</sup><span>'.$amount.'</span>/ '.$period.'</div>';
			$output .= '<ul>';
			
			$values = (array) vc_param_group_parse_atts($values);
	        foreach($values as $v) {
			$output .= '<li>'.$v['listitem'].'</li>';
			}
			$output .= '</ul>';
				?>
				
				<style>
					 <?php $hovercolor1 = str_replace(array('#','.',',','(',')'),'',$hovercolor); ?>

					.klb-button .klb_<?php echo esc_html($hovercolor1) ?>:hover {
							background-color: <?php echo esc_html($hovercolor); ?>;			
					}
					.klb-button .klb_<?php echo esc_html($hovercolor1) ?>{
						background-color: <?php echo esc_html($backgroundcolor); ?>;
					}
				</style>
				
				<?php
				$alignment = '';
				
				if($btnalignment == 'center'){
				  $alignment .= 'center';
				} elseif($btnalignment == 'right'){
				  $alignment .= 'right';	
				} else {
				  $alignment .= 'left';	
				}
						$link = ( '||' === $link ) ? '' : $link;
						$link = vc_build_link( $link );
						$a_href = $link['url'];
						$a_title = $link['title'];
						$a_target = $link['target'];
						
				$output .= '<div class="klb-button" style="text-align:'.esc_html($alignment).';">';
				if($icons){
					$useicon .= '<i class="'.$icon_fontawesome.'"></i>';
				}
				if($btn_type == '1'){
					$btn_class = 'btn';
				}elseif($btn_type == '2'){
					$btn_class = 'btn-s';
				}elseif($btn_type == '3'){
					$btn_class = 'btn-l';
				}elseif($btn_type == '4'){
					$btn_class = 'btn-bordered';
				}elseif($btn_type == '5'){
					$btn_class = 'btn-bordered btn-s';
				}elseif($btn_type == '6'){
					$btn_class = 'btn-bordered btn-l';
				}
				$output .= '<a class="btn '.esc_attr( $btn_class ).' klb_'.$hovercolor1.'" style="border-color:'.esc_attr($bordercolor).';color:'.esc_attr($buttoncolor).'" href="'.esc_attr( $a_href ).'" target="'.esc_attr( $a_target ).'" title="'.esc_attr( $a_title ).'">'.$useicon.''.esc_html( $a_title ).'</a>';
				$output .= '</div>';
			$output .= '</div>';
		
  		return $output;
}

add_shortcode('pricing_unica', 'unica_pricing');
/*-----------------------------------------------------------------------------------*/
/*	Unica Socials
/*-----------------------------------------------------------------------------------*/

function unica_socials( $atts, $content = null ) {
    extract( shortcode_atts(array(       
		"icon_fontawesome"   => '',
		"addsep"   		 => '',
		"sepcolor"   		 => '',
		"bgcolor"   		 => '',
		"socialurl"  		 => '',
		"iconcolor"  		 => '',
		"coloricon"  		 => '',
		"hovercolor"  		 => '',
		"values"  			 => '',

    ), $atts) );


		$output = '';
		$output .= '<ul class="social-nav center">';
		$values = (array) vc_param_group_parse_atts($values);
		 foreach($values as $v) {
			 ?>
			 			<style>
				 <?php $hovercolor1 = str_replace(array('#','.',',','(',')'),'',$v['hovercolor']); ?>

				.klb_<?php echo esc_html($hovercolor1) ?>:hover {
						color: <?php echo esc_html($v['hovercolor']); ?>!important;			
				}
			</style>
<?php
		$output .= '<li style="color:'.esc_attr($v['iconcolor']).'"><a href="'.$v['socialurl'].'" class="klb_'.$hovercolor1.'"><i class="'.$v['icon_fontawesome'].'"></i></a></li>';
		}
		$output .= '</ul>';
	    if($addsep == true ){
		$output .= '<div style="color:'.esc_attr( $sepcolor ).';" class="separator"></div>';
		}


  		return $output;
}

add_shortcode('socials_unica', 'unica_socials');
/*-----------------------------------------------------------------------------------*/
/*  Unica Map Container
/*-----------------------------------------------------------------------------------*/
function unica_map_container( $atts, $content = null ) {	
$css = '';
 	extract(shortcode_atts(array(
       	'latitude'      => '51.5209564',
       	'longitude' => '0.157134',
        'zoom'      => '10',
        'css' => '',
        'height' => '400',
        'image_url' => '',
        'watercolor' => '',
        'roadcolor' => '',
        'landcolor' => '',
        'arterialcolor' => '',
        'localroadcolor' => '',
        'parkcolor' => '',
        'acolor' => '',
        'marktitle' => '',
        'markdesc' => '',
        'markemail' => '',
        'markphone' => '',
        'markwebsite' => '',
    ), $atts)); 
	wp_enqueue_script('googlemap');
?>

<script type="text/javascript"> 
jQuery(document).ready(function() {
    google.maps.event.addDomListener(window, 'load', init);
    var map;
    function init() {
        var mapOptions = {
            center: new google.maps.LatLng(<?php echo esc_attr($latitude); ?>,<?php echo esc_attr($longitude); ?>),
            zoom: <?php echo esc_attr($zoom); ?>,
            zoomControl: true,
            zoomControlOptions: {
                style: google.maps.ZoomControlStyle.DEFAULT,
            },
            disableDoubleClickZoom: true,
            mapTypeControl: true,
            mapTypeControlOptions: {
                style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
            },
			scrollwheel: false,
            scaleControl: true,           
            panControl: true,
            streetViewControl: true,
            draggable : true,
            overviewMapControl: true,
            overviewMapControlOptions: {
                opened: false,
            },
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            styles: [
    {
        "featureType": "water",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "color": "<?php echo esc_attr($watercolor); ?>"
            }
        ]
    },
    {
        "featureType": "landscape",
        "stylers": [
            {
                "color": "<?php echo esc_attr($landcolor); ?>"
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "<?php echo esc_attr($roadcolor); ?>"
            }
        ]
    },
    {
        "featureType": "road.arterial",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "<?php echo esc_attr($arterialcolor); ?>"
            }
        ]
    },
    {
        "featureType": "road.local",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "<?php echo esc_attr($localroadcolor); ?>"
            }
        ]
    },
    {
        "featureType": "poi.park",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "<?php echo esc_attr($parkcolor); ?>"
            }
        ]
    },
    {
        "featureType": "administrative",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "lightness": 33
            }
        ]
    },
    {
        "featureType": "road"
    },
    {
        "featureType": "poi.park",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "lightness": 20
            }
        ]
    },
    {},
    {
        "featureType": "road",
        "stylers": [
            {
                "lightness": 20
            }
        ]
    }
],
        }
        var mapElement = document.getElementById('unica');
        var map = new google.maps.Map(mapElement, mapOptions);
        var locations = [
		<?php $image_urls = wp_get_attachment_url( $image_url, 'full' ); ?>
['<?php echo esc_attr($marktitle); ?>', '<?php echo esc_attr($markdesc); ?>', '<?php echo esc_attr($markphone); ?>', '<?php echo esc_attr($markemail); ?>', '<?php echo esc_attr($markwebsite); ?>', -37.8136276, 144.96305759999996, '<?php echo esc_attr($image_urls); ?>']
        ];
        for (i = 0; i < locations.length; i++) {
			if (locations[i][1] =='undefined'){ description ='';} else { description = locations[i][1];}
			if (locations[i][2] =='undefined'){ telephone ='';} else { telephone = locations[i][2];}
			if (locations[i][3] =='undefined'){ email ='';} else { email = locations[i][3];}
           if (locations[i][4] =='undefined'){ web ='';} else { web = locations[i][4];}
           if (locations[i][7] =='undefined'){ markericon ='';} else { markericon = locations[i][7];}
            marker = new google.maps.Marker({
                icon: markericon,
                position: {lat: <?php echo esc_attr($latitude); ?>, lng: <?php echo esc_attr($longitude); ?>},
                map: map,
                title: locations[i][0],
                desc: description,
                tel: telephone,
                email: email,
                web: web
            });
if (web.substring(0, 7) != "http://") {
link = "http://" + web;
} else {
link = web;
}
            bindInfoWindow(marker, map, locations[i][0], description, telephone, email, web, link);
     }
 function bindInfoWindow(marker, map, title, desc, telephone, email, web, link) {
      var infoWindowVisible = (function () {
              var currentlyVisible = false;
              return function (visible) {
                  if (visible !== undefined) {
                      currentlyVisible = visible;
                  }
                  return currentlyVisible;
               };
           }());
           iw = new google.maps.InfoWindow();
           google.maps.event.addListener(marker, 'click', function() {
               if (infoWindowVisible()) {
                   iw.close();
                   infoWindowVisible(false);
               } else {
                   var html= "<div style='color:#000;background-color:#fff;padding:5px;width:150px;'><h4>"+title+"</h4><p>"+desc+"<p><p>"+telephone+"<p><a href='mailto:"+email+"' >"+email+"<a><a href='"+link+"'' >"+web+"<a></div>";
                   iw = new google.maps.InfoWindow({content:html});
                   iw.open(map,marker);
                   infoWindowVisible(true);
               }
        });
        google.maps.event.addListener(iw, 'closeclick', function () {
            infoWindowVisible(false);
        });
 }
}
});
</script>
<style>
    #unica {
        height:<?php echo esc_attr($height); ?>px;
    }
    .gm-style-iw * {
        display: inline-block;
		text-align: center;
	
    }
    .gm-style-iw h4, .gm-style-iw p {
        margin: 0;
        padding: 0;		
    }
    .gm-style-iw a {
        color: <?php echo esc_attr($acolor); ?>;
    }
</style>

<div id='unica' class="full-width"></div>

<?php 
            $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

	        $output = '';
			
			
			


   return $output;

}

add_shortcode('map_container', 'unica_map_container');

/*-----------------------------------------------------------------------------------*/
/*  Unica Latest Blog
/*-----------------------------------------------------------------------------------*/

function unica_bloglatest($atts){
	extract(shortcode_atts(array(
       	'posts'      => '4',
       	'categories' => 'all',
		'excerpt_size' => '31',			
		'my_var' => '',			
    ), $atts));
    
    global $post;
	$blog_post_type = '';

	$args = array(
		'post_type' => 'post',
		'posts_per_page' => $posts,
		'order'          => 'DESC',
		'orderby'        => 'date',
		'post_status'    => 'publish',
		'post_taxonomy'    => $categories
    );

    if($categories != 'all'){
    	
    	// string to array
    	$str = $categories;
    	$arr = explode(',', $str);
    	//var_dump($arr);
    	
		$args['tax_query'][] = array(
			'taxonomy' 	=> 'category',
			'field' 	=> 'slug',
			'terms' 	=> $arr
		);
	}

    query_posts( $args );		
    $out = '';
	
	if( have_posts() ) : while ( have_posts() ) : the_post();

			    $out .= '';			
				$my_var = get_comments_number();
				$blog_thumbnail= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "blog-thumb" );
			    $image = unica_resize( $blog_thumbnail[0], 440, 214, true, true, true );   
                
				$terms = get_the_terms( get_the_ID(), 'category' );
                $taxonomy = strip_tags( get_the_term_list($post->ID, 'category', '', ', ', '') );
               
			$post_format = '';
               if(has_post_thumbnail()){
					$blog_image= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "full" );	
					$thumb = unica_resize( $blog_image[0], 600, 305, true, true, true ); 
					$post_format .= '<img src="'.$thumb.'" alt="'.get_the_title().'">';
				}elseif(has_post_format( 'audio' )){ 
					$blog_image= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), "full" );				
					$post_format .= '<figure class="entry-thumb klb-audio-front">'.get_post_meta($post->ID, 'klb_blogaudiourl', true).'</figure>';
				}elseif ( has_post_format( 'gallery' )) {
					 $images = rwmb_meta( 'klb_blogitemslides', 'type=image_advanced' ); 
					 $post_format .= '<div class="slideshow owl-carousel owl-theme">';
					 foreach (  $images as $image  ) {
					  $slideaq = unica_resize( $image['full_url'], 600, 305, true, true, true ); 
					  $post_format .= '<div class="item"><img src="'.$slideaq.'" alt="'.get_the_title().'" /></div>';
					 }
					 $post_format .= '</div>';			
				}elseif ( has_post_format( 'video' )) {						
				   $post_format .= '<div class="entry-media">';
				   if (get_post_meta( get_the_ID(), 'klb_blog_video_type', true ) == 'vimeo') { 
					  $post_format .='<iframe src="http://player.vimeo.com/video/'.get_post_meta( get_the_ID(), 'klb_blog_video_embed', true ).'?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" width="100%" height="236" allowFullScreen></iframe>'; 
				   }
				   elseif (get_post_meta( get_the_ID(), 'klb_blog_video_type', true ) == 'youtube') { 
					$post_format .='<iframe width="100%" height="236" src="http://www.youtube.com/embed/'.get_post_meta( get_the_ID(), 'klb_blog_video_embed', true ).'?rel=0&showinfo=0&modestbranding=1&hd=1&autohide=1&color=white" allowfullscreen></iframe>';  
				   }
				   else {  
					$post_format .=' '.get_post_meta( get_the_ID(), 'klb_blog_video_embed', true ).' '; 
				   } 
				   $post_format .= '</div>';		   
				}				
		$out .= '<div class="item">';
		$out .= $post_format;;

		$out .= '<div class="blog-content">';
		$out .= '<div class="p-t-20"></div>';
		$out .= '<ul class="blog-socials">';
		$out .= '<h3><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>';
		$out .= '<li><a href="'.get_the_permalink().'"><i class="fa fa-calendar"></i><span>'.get_the_date().'</span></a></li>';
		$out .= '</ul>';
		$out .= '<div class="klb-post">';
		$out .= '<p>'.get_the_excerpt().'</p>';
		$out .= '</div>';
		$out .= '</div>';
		$out .= '</div>';

		endwhile;
		 wp_reset_query();
	endif;
	
	return  '<div id="owl-blog" class="owl-carousel owl-theme">'.$out.'</div>';
}


add_shortcode('blog_latest', 'unica_bloglatest');